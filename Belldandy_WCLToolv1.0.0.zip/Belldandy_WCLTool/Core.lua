local addonName, addon = ...
local defaults = {
    ["isUse"] = true,
    ["isUseText"] = "已开启",
    ["isBoBao"] = false,
    ["isWelcome"] = true,
    ["WelcomeText"] = "欢迎加入贝露丹迪，撒花！",
}

-- [插件载入]
local Addon_EventFrame = CreateFrame("Frame")
Addon_EventFrame:RegisterEvent("ADDON_LOADED")
-- Addon_EventFrame:RegisterEvent("PLAYER_LOGIN")
-- Addon_EventFrame:RegisterEvent("PLAYER_LOGOUT")
Addon_EventFrame:SetScript("OnEvent", function(self, event, addon)
    if event == "ADDON_LOADED" then
        if addon == "Belldandy_WCLTool" then
            Belldandy_WCLToolDB = Belldandy_WCLToolDB

            if type(Belldandy_WCLToolDB) ~= "table" or next(Belldandy_WCLToolDB) == nil then
                Belldandy_WCLToolDB = defaults

            end
            if #defaults > #Belldandy_WCLToolDB then
                Belldandy_WCLToolDB = defaults
            end

            --5秒后再加载，确保是最后hook，这样才能不被其他插件覆盖掉信息
            C_Timer.After(5, function()

                if WCLBOX_PLAYER_DATA then
                    print("|cffFF83FA<贝露丹迪>Belldandy|r|cff16C3F2WCL工具|r加载成功")
                    local usetext
                    if Belldandy_WCLToolDB.isUse then
                        usetext = "|cff00FFFF已启用"
                    else
                        usetext = "|cffff0000未启用"
                    end

                    print(
                        "|r插件当前状态：" .. usetext)
                else
                    print(
                        "|cffff0000加载失败，请向贝露丹迪的神反馈~|r")
                end
                Hook()
            end)
        end
    else
        Belldandy_WCLToolDB = Belldandy_WCLToolDB
    end


end)

function Hook()
    -- hook角色右键菜单
    hooksecurefunc("UnitPopup_ShowMenu",
        function(dropdownMenu, which, unit, name, userData)
            local WP_TargetName = dropdownMenu.name

            if UIDROPDOWNMENU_MENU_LEVEL ~= 2 then

                if (which == "SELF" or which == "PLAYER" or which == "PARTY" or
                    which == "RAID_PLAYER" or which == "ENEMY_PLAYER" or which ==
                    "TARGET" or which == "FOCUS") and UnitIsPlayer(unit) then

                    local info = UIDropDownMenu_CreateInfo()
                    info.text = '|cffFF83FA<贝露丹迪>|r|cff16C3F2WCL信息查询'
                    info.owner = which
                    info.notCheckable = 1
                    info.tooltipOnButton = true
                    info.tooltipTitle =
                    '|cffffcf00有问题找贝露丹迪的神|r'

                    UIDropDownMenu_AddSeparator()
                    UIDropDownMenu_AddButton(info)
                    UIDropDownMenu_AddSeparator()

                    local function menu(text)
                        local info2 = UIDropDownMenu_CreateInfo()
                        info2.text = text
                        info2.owner = which
                        info2.notCheckable = 1
                        info2.tooltipOnButton = false
                        UIDropDownMenu_AddButton(info2)
                    end

                    Add_menu(WP_TargetName, GetGuildInfo(unit), menu);

                    -- add_menu('|cffff8000本服DPS第1术士 8769.5秒伤|r')

                    -- add_menu('|cffa335ee本服全明星第15术士 2976.6分|r')

                    -- add_menu('|cff0070ff本服全明星第15术士 2976.6分|r')

                    -- add_menu('|cff666666本服全明星第15术士 2976.6分|r')

                    UIDropDownMenu_AddSeparator()

                    menu('更新于:' .. Gethxtime())
                end

            end

        end)

    -- hook右下角tip提示
    GameTooltip:HookScript("OnTooltipSetUnit", function(self)
        local _, unit = self:GetUnit()
        local dstr = ""
        local dstrr = ""
        if UnitExists(unit) and UnitIsPlayer(unit) then
            local unit_name = UnitName(unit)
            GameTooltip:AddLine('------------------------')
            Add_tip(unit_name, GetGuildInfo(unit), GameTooltip)
            GameTooltip:AddLine('------------------------')
            GameTooltip:AddLine('|cffFF83FA<贝露丹迪>|r|cff16C3F2WCL|r 更新于:' ..
                Gethxtime())
            GameTooltip:Show()

        end
    end)

    hooksecurefunc("ChatFrame_OnHyperlinkShow",
        function(chatFrame, link, text, button)

            if (link and button) then
                local args = {};
                for v in string.gmatch(link, "[^:]+") do
                    table.insert(args, v);
                end

                local menuFrame = CreateFrame("Frame", nil, UIParent,
                    "UIDropDownMenuTemplate")

                local menu = {}
                if (args[1] and args[1] == "player") then
                    args[2] = Ambiguate(args[2], "short")
                    local name = args[2]
                    WclBox.add_chat_tip(name, null, menu);
                    EasyMenu(menu, menuFrame, "cursor", PlayerLinkList:GetWidth(),
                        0, "MENU", 3);
                end
            end

        end)

    -- [公会成员列表热键显示]
    for i = 1, GUILDMEMBERS_TO_DISPLAY do
        _G["GuildFrameButton" .. i]:RegisterForClicks("AnyDown")
        _G["GuildFrameButton" .. i]:HookScript("OnClick", function(self, button)

            local name = _G["GuildFrameButton" .. i .. "Name"]:GetText()

            local menu = {}
            local menuFrame = CreateFrame("Frame", nil, UIParent,
                "UIDropDownMenuTemplate")
            Add_chat_tip(name, GetGuildInfo("player"), menu);
            EasyMenu(menu, menuFrame, "cursor", PlayerLinkList:GetWidth(), 0,
                "MENU", 3);

        end)
    end

end

function Add_menu(name, guild_name, menu)

    local rank1 = GetRankhx(name, 1);
    local rank2 = GetRankhx(name, 2);
    local rank3 = GetRankhx(name, 3);
    local guild = GetGuild(guild_name)

    if (rank1) then menu(rank1) end

    if (rank2) then menu(rank2) end

    if (rank3) then menu(rank3) end

    if (guild) then menu(guild) end

    if not rank1 and not rank2 and not rank3 and not guild then
        menu("|cFFff0000未查询到玩家WCL数据|R")
    end

end

function Add_tip(name, guild_name, tip)

    local rank1 = GetRankhx(name, 1);
    local rank2 = GetRankhx(name, 2);
    local rank3 = GetRankhx(name, 3);
    local guild = GetGuild(guild_name)

    if (rank1) then tip:AddLine(rank1) end

    if (rank2) then tip:AddLine(rank2) end

    if (rank3) then tip:AddLine(rank3) end

    if (guild) then tip:AddLine(guild) end

    if not rank1 and not rank2 and not rank3 and not guild then
        tip:AddLine("|cFFff0000未查询到玩家WCL数据|R")
    end

end

function Add_chat_tip(name, guild_name, menu)

    local rank1 = GetRankhx(name, 1);
    local rank2 = GetRankhx(name, 2);
    local rank3 = GetRankhx(name, 3);
    local guild = GetGuild(guild_name)

    tinsert(menu, { text = name, notCheckable = true, notClickable = true })
    tinsert(menu, {
        text = "------------------------",
        notCheckable = true,
        notClickable = true
    })
    if (rank1) then
        tinsert(menu, { text = rank1, notCheckable = true, notClickable = true })
    end

    if (rank2) then
        tinsert(menu, { text = rank2, notCheckable = true, notClickable = true })
    end

    if (rank3) then
        tinsert(menu, { text = rank3, notCheckable = true, notClickable = true })
    end

    if (guild) then
        tinsert(menu, { text = guild, notCheckable = true, notClickable = true })
    end

    if not rank1 and not rank2 and not rank3 and not guild then
        tinsert(menu, {
            text = "|cFFff0000未查询到玩家WCL数据|R",
            notCheckable = true,
            notClickable = true
        })
    end

    tinsert(menu, {
        text = "------------------------",
        notCheckable = true,
        notClickable = true
    })
    tinsert(menu, {
        text = '|cffFF83FA<贝露丹迪>|r|cff16C3F2WCL信息查询|r 更新于:' .. Gethxtime(),
        notCheckable = true,
        notClickable = true
    })

end

--local IsUse=true
function GetRankhx(name, rank)
    if not WCLBOX_PLAYER_DATA or not name or not rank then return end
    if WCLBOX_PLAYER_DATA[name] and
        WCLBOX_PLAYER_DATA[name][rank] then
        return WCLBOX_PLAYER_DATA[name][rank]
    end
end

function GetGuild(guild)
    if not WCLBOX_GUILD_SPEED or not guild then return end
    if WCLBOX_GUILD_SPEED[tostring(guild)] then
        return WCLBOX_GUILD_SPEED[tostring(guild)]
    end
end

function Gethxtime()

    local time = GetServerTime() - (WCLBOX_UPDATE_TIME or 0)

    local time_str =
    "1个月前 (数据太旧，请尽快更新）"

    if (time / 86400 < 2) then
        time_str = (string.format("%.0f", time / 3600)) ..
            "小时前"
    elseif (time / 86400 < 7) then
        time_str = (string.format("%.0f", time / 3600)) ..
            "小时前"
    elseif (time / 86400 < 15) then
        time_str = (string.format("%.0f", time / 3600)) ..
            "小时前 (数据太旧，请尽快更新）"
    elseif (time / 86400 < 30) then
        time_str = (string.format("%.0f", time / 3600)) ..
            "小时前 (数据太旧，请尽快更新）"
    end

    return time_str

end

function Strrank(str)
    local aa = str
    local lenstr = #aa

    local lenjq = string.find(aa, "本服")

    local lenrank = string.sub(aa, lenjq, lenstr - 2)
    return lenrank
end

function HX(self, event, arg1, ...)

    local dz = UnitIsGroupLeader("player")
    if Belldandy_WCLToolDB.isBoBao then dz = true end
    if event == "CHAT_MSG_SYSTEM" then
        if Belldandy_WCLToolDB.isUse == true and dz == true then


            local inRaid = UnitInRaid("Player")
            if inRaid then
                local s = string.find(arg1, "加入了团队")

                if s ~= nil then

                    local rankmsg = ""

                    local len = string.find(arg1, "加入了团队。")
                    local name = string.sub(arg1, 1, len - 1)

                    local rank1 = GetRankhx(name, 1)

                    local rank2 = GetRankhx(name, 2)

                    local rank3 = GetRankhx(name, 3)

                    if rank1 ~= nil then

                        rankmsg = rankmsg .. " " .. Strrank(rank1)
                    end
                    if rank2 ~= nil then
                        rankmsg = rankmsg .. " " .. Strrank(rank2)
                    end
                    if rank3 ~= nil then
                        rankmsg = rankmsg .. " " .. Strrank(rank3)
                    end
                    if rankmsg ~= "" then
                        local endmsg = "<" .. name .. "> " .. rankmsg .. "的玩家加入了团队 --(更新于" ..
                            Gethxtime() .. ")"
                        SendChatMessage(endmsg, "RAID", nil, nil)
                    end


                end
            else
                local s = string.find(arg1, "加入了队伍")

                if s ~= nil then

                    local rankmsg = ""

                    local len = string.find(arg1, "加入了队伍。")
                    local name = string.sub(arg1, 1, len - 1)

                    local rank1 = GetRankhx(name, 1)

                    local rank2 = GetRankhx(name, 2)

                    local rank3 = GetRankhx(name, 3)

                    if rank1 ~= nil then

                        rankmsg = rankmsg .. " " .. Strrank(rank1)
                    end
                    if rank2 ~= nil then
                        rankmsg = rankmsg .. " " .. Strrank(rank2)
                    end
                    if rank3 ~= nil then
                        rankmsg = rankmsg .. " " .. Strrank(rank3)
                    end
                    if rankmsg ~= "" then
                        local endmsg = "<" .. name .. "> " .. rankmsg .. "的玩家加入了队伍 --(更新于" ..
                            Gethxtime() .. ")"
                        SendChatMessage(endmsg, "PARTY", nil, nil)
                    end


                end
            end
        end

        if Belldandy_WCLToolDB.isWelcome then
            local s = string.find(arg1, "加入了公会")

            if s ~= nil then
                C_Timer.After(1, function()




                    if Belldandy_WCLToolDB.WelcomeText ~= "" then

                        SendChatMessage(Belldandy_WCLToolDB.WelcomeText, "GUILD", nil, nil)
                    else
                        SendChatMessage("欢迎欢迎", "GUILD", nil, nil)
                    end

                end)
            end
        end
    end

end

local MainUI = CreateFrame("Frame");
MainUI:RegisterEvent("CHAT_MSG_SYSTEM")

MainUI:SetPoint("LEFT", UIParent, "LEFT");
MainUI:SetScript("OnEvent", HX)
-- 注册聊天窗口命令
-- SLASH_Start1 = '/hx'
-- SlashCmdList['Start'] = function()

--     --BLDD_HX.isUseText="已开启"
--     if Belldandy_WCLToolDB.isUse then
--         Belldandy_WCLToolDB.isUse = false
--         Belldandy_WCLToolDB.isUseText = "已关闭"
--     else
--         Belldandy_WCLToolDB.isUse = true
--         Belldandy_WCLToolDB.isUseText = "已开启"
--     end

--     print("|r ----------------------------------------")
--     print("|r ----------------------------------------")
--     print("      |r |cffFF83FA贝露丹迪旋哥装逼|r插件 " .. "|cff16C3F2" .. Belldandy_WCLToolDB.isUseText)
--     print("|r ----------------------------------------")
--     print("|r ----------------------------------------")
-- end
SLASH_BoBao1 = '/mywcl'
SlashCmdList['BoBao'] = function()

    InterfaceOptionsFrame_OpenToCategory(addon.optpanels.ABOUT.name)
    InterfaceOptionsFrame_OpenToCategory(addon.optpanels.ABOUT.name)
end
