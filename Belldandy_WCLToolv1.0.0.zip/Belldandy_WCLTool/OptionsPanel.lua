local addonName, addon = ...
local L = addon.L

local LibDropDown = LibStub("LibDropDown")

-- local optionsabout = CreateFrame('Frame', '设置主框架', InterfaceOptionsFramePanelContainer)
-- optionsabout.name = '|cffFF83FA<貝露丹迪>|r|cff16C3F2WCL工具'
-- optionsabout:Hide()

local about = CreateFrame("Frame", addonName .. "设置主框架", InterfaceOptionsFramePanelContainer)
about.name = '|cffFF83FA<贝露丹迪>|r|cff16C3F2WCL工具'
about:Hide()
local MAX_HIGHLIGHT_LEN = 99999999

function about.OnShow(frame)
        local fields = { "Version", "Author" }
        local notes = GetAddOnMetadata(addonName, "Notes")

        local title = frame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")

        title:SetPoint("TOPLEFT", 16, -16)
        title:SetText('|cffFF83FA<贝露丹迪Belldandy>|r|cff16C3F2WCL工具')

        local subtitle = frame:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
        subtitle:SetHeight(32)
        subtitle:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -8)
        subtitle:SetPoint("RIGHT", about, -32, 0)
        subtitle:SetNonSpaceWrap(true)
        subtitle:SetJustifyH("LEFT")
        subtitle:SetJustifyV("TOP")
        subtitle:SetText(notes)

        local anchor
        for _, field in pairs(fields) do
                local val = GetAddOnMetadata(addonName, field)
                if val then
                        local title = frame:CreateFontString(nil, "ARTWORK", "GameFontNormalSmall")
                        title:SetWidth(75)
                        if not anchor then title:SetPoint("TOPLEFT", subtitle, "BOTTOMLEFT", -2, -8)
                        else title:SetPoint("TOPLEFT", anchor, "BOTTOMLEFT", 0, -6) end
                        title:SetJustifyH("RIGHT")
                        title:SetText(field:gsub("X%-", ""))

                        local detail = frame:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
                        detail:SetPoint("LEFT", title, "RIGHT", 4, 0)
                        detail:SetPoint("RIGHT", -16, 0)
                        detail:SetJustifyH("LEFT")
                        detail:SetText(val)

                        anchor = title
                end
        end

        -- Clear the OnShow so it only happens once
        frame:SetScript("OnShow", nil)
end

addon.optpanels = addon.optpanels or {}
addon.optpanels.ABOUT = about

about:SetScript("OnShow", about.OnShow)
InterfaceOptions_AddCategory(addon.optpanels.ABOUT)


local panel = CreateFrame("Frame")
panel.name = "WCL全明星分数排名播报设置"
panel.parent = '|cffFF83FA<贝露丹迪>|r|cff16C3F2WCL工具' --addonName.. "设置主框架"

-- addon.optpanels.GENERAL = panel
panel:SetScript("OnShow", function(self)
        if not panel.initialized then
                panel:CreateOptions()
                panel.refresh()
        end
end)

--[创建单选框]
local function make_checkbox(name, parent)
        local frame = CreateFrame("CheckButton", name, parent, "UICheckButtonTemplate")
        frame.text = _G[frame:GetName() .. "Text"]
        frame.type = "checkbox"
        return frame
end

--[创建下拉框]
local function make_dropdown(name, parent)
        local frame = LibDropDown:NewButton(parent, name)
        frame.type = "dropdown"
        frame:SetStyle("MENU")
        return frame
end

--[创建label]
local function make_label(name, parent, template)
        local label = parent:CreateFontString(name, "OVERLAY", template)
        label:SetWidth(parent:GetWidth())
        label:SetJustifyH("LEFT")
        label.type = "label"
        return label
end

--[创建输出按钮框]
local function make_editbox_with_button(editName, buttonName, parent)
        local editbox = CreateFrame("EditBox", editName, parent)
        editbox:SetHeight(32)
        editbox:SetWidth(350)
        editbox:SetAutoFocus(false)
        editbox:SetFontObject('GameFontHighlightSmall')
        editbox.type = "editbox"

        local left = editbox:CreateTexture(nil, "BACKGROUND")
        left:SetWidth(8)
        left:SetHeight(20)
        left:SetPoint("LEFT", -5, 0)
        left:SetTexture("Interface\\Common\\Common-Input-Border")
        left:SetTexCoord(0, 0.0625, 0, 0.625)

        local right = editbox:CreateTexture(nil, "BACKGROUND")
        right:SetWidth(8)
        right:SetHeight(20)
        right:SetPoint("RIGHT", 0, 0)
        right:SetTexture("Interface\\Common\\Common-Input-Border")
        right:SetTexCoord(0.9375, 1, 0, 0.625)

        local center = editbox:CreateTexture(nil, "BACKGROUND")
        center:SetHeight(20)
        center:SetPoint("RIGHT", right, "LEFT", 0, 0)
        center:SetPoint("LEFT", left, "RIGHT", 0, 0)
        center:SetTexture("Interface\\Common\\Common-Input-Border")
        center:SetTexCoord(0.0625, 0.9375, 0, 0.625)

        editbox:SetScript("OnEscapePressed", editbox.ClearFocus)
        editbox:SetScript("OnEnterPressed", editbox.ClearFocus)
        editbox:SetScript("OnEditFocusGained", function()
                -- editbox:HighlightText(0, MAX_HIGHLIGHT_LEN)
        end)

        local button = CreateFrame("Button", buttonName, editbox, "UIPanelButtonTemplate")
        button:Show()
        button:SetHeight(22)
        button:SetWidth(75)
        button:SetPoint("LEFT", editbox, "RIGHT", 0, 0)
        return editbox, button
end

function panel:CreateOptions()
        -- Ensure the panel isn't created twice (thanks haste)
        panel.initialized = true
        -- Create the general options panel here:
        local bits = {}

        self.isusebobao = make_checkbox("IsUseBoBao", self)
        self.isusebobao.text:SetText("是否启用播报功能（在团队或者队伍中为队长时播报玩家WCL排名）")

        self.nocaptonbobao = make_checkbox("NoCaptonBoao", self)
        self.nocaptonbobao.text:SetText("非团队领袖或者队长时进行播报")

        -- if addon:ProjectIsClassic() then
        -- end

        -- print(Belldandy_WCLToolDB.isUse)


        -- Collect and anchor the bits together
        table.insert(bits, self.isusebobao)
        table.insert(bits, self.nocaptonbobao)



        bits[1]:SetPoint("TOPLEFT", 5, -5)
        bits[2]:SetPoint("TOPLEFT", bits[1], "BOTTOMLEFT", 0, -5)

end

function panel.refresh()

        xpcall(function()
                if not panel.initialized then
                        panel:CreateOptions()
                end

                -- Initialize the dropdowns
                -- local settings = addon.settings
                -- local currentProfile = addon.db:GetCurrentProfile()


                panel.isusebobao:SetChecked(Belldandy_WCLToolDB.isUse)
                panel.nocaptonbobao:SetChecked(Belldandy_WCLToolDB.isBoBao)
        end, geterrorhandler())
end

function panel.okay()


        xpcall(function()

                -- Update the saved variables
                Belldandy_WCLToolDB.isUse = not not panel.isusebobao:GetChecked()
                Belldandy_WCLToolDB.isBoBao = not not panel.nocaptonbobao:GetChecked()
        end, geterrorhandler())

end

panel.cancel = panel.refresh

local panel2 = CreateFrame("Frame")
panel2.name = "公会新成员欢迎语设置"
panel2.parent = '|cffFF83FA<贝露丹迪>|r|cff16C3F2WCL工具' --addonName.. "设置主框架"
panel2:SetScript("OnShow", function(self)
        if not panel2.initialized then
                panel2:CreateOptions()
                panel2.refresh()
        end
end)
function panel2:CreateOptions()
        -- Ensure the panel isn't created twice (thanks haste)
        panel2.initialized = true
        -- Create the general options panel here:
        local bits = {}

        self.iswelcome = make_checkbox("IsWelcomeNewMember", self)
        self.iswelcome.text:SetText("是否启用公会新成员欢迎语")

        self.setwelcometext = make_label("welcometextLabel", self, "GameFontNormalSmall")
        self.setwelcometext:SetText("设置欢迎语")
        self.welcometextbox, self.welcometextbutton = make_editbox_with_button("welcometextboxEditbox",
                "welcometextboxEditboxButton", self)

        self.welcometextbutton:SetText("确定")
        self.welcometextbutton:SetScript("OnClick", function(self, button)
                local payload = addon:GetExportString()
                local editbox = self:GetParent()
                local text = editbox:GetText()
                editbox:ClearFocus()
                if #text < 1 then
                        Belldandy_WCLToolDB.WelcomeText = "欢迎加入贝露丹迪，撒花！";
                else
                        Belldandy_WCLToolDB.WelcomeText = text;
                end

        end)
        -- if addon:ProjectIsClassic() then
        -- end

        -- print(Belldandy_WCLToolDB.isUse)


        -- Collect and anchor the bits together
        table.insert(bits, self.iswelcome)
        table.insert(bits, self.setwelcometext)
        table.insert(bits, self.welcometextbox)



        bits[1]:SetPoint("TOPLEFT", 5, -5)
        bits[1]:SetPoint("TOPLEFT", 5, -5)

        for i = 2, #bits, 1 do
                if bits[i].type == "label" then
                        if bits[i - 1].type == "editbox" then
                                bits[i]:SetPoint("TOPLEFT", bits[i - 1], "BOTTOMLEFT", -15, -5)
                        else
                                bits[i]:SetPoint("TOPLEFT", bits[i - 1], "BOTTOMLEFT", 5, -5)
                        end
                elseif bits[i].type == "dropdown" then
                        bits[i]:SetPoint("TOPLEFT", bits[i - 1], "BOTTOMLEFT", -5, -5)
                elseif bits[i].type == "editbox" then
                        bits[i]:SetPoint("TOPLEFT", bits[i - 1], "BOTTOMLEFT", 15, -5)
                else
                        bits[i]:SetPoint("TOPLEFT", bits[i - 1], "BOTTOMLEFT", 0, -5)
                end
        end

end

function panel2.refresh()

        xpcall(function()
                if not panel2.initialized then
                        panel2:CreateOptions()
                end

                -- Initialize the dropdowns
                -- local settings = addon.settings
                -- local currentProfile = addon.db:GetCurrentProfile()


                panel2.iswelcome:SetChecked(Belldandy_WCLToolDB.isWelcome)
                panel2.welcometextbox:SetText(Belldandy_WCLToolDB.WelcomeText)
                panel2.welcometextbox:SetCursorPosition(0)
        end, geterrorhandler())
end

function panel2.okay()


        xpcall(function()

                -- Update the saved variables
                Belldandy_WCLToolDB.isWelcome = not not panel2.iswelcome:GetChecked()
                Belldandy_WCLToolDB.WelcomeText =  panel2.welcometextbox:GetText()
        end, geterrorhandler())

end

panel2.cancel = panel2.refresh
InterfaceOptions_AddCategory(panel, addon.optpanels.ABOUT)
InterfaceOptions_AddCategory(panel2, addon.optpanels.ABOUT)